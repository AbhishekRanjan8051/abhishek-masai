const express = require("express");

const mongoose = require("mongoose");

const connect = () => {
  return mongoose.connect("mongodb://127.0.0.1:27017/web11");
};

//create the schema

const userSchema = new mongoose.Schema(
  {
    id: { type: Number, required: true },
    first_name: { type: String, required: true },
    last_name: { type: String, required: false },
    email: { type: String, required: true },
    gender: { type: String, required: true },
  },
  {
    versionKey: false,
    timestamps: true,
  }
);

// connect the schema to the user collewction

const User = mongoose.model("user", userSchema);

// create schema for post

const postSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    body: { type: String, required: true },
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
      required: true,
    },
    tags: [
      { type: mongoose.Schema.Types.ObjectId, ref: "tag", required: true },
    ],
  },
  {
    versionKey: false,
    timestamps: true,
  }
);

//connect post to collection

const Post = mongoose.model("post", postSchema);

//crete schema for commentedJSON

const commentSchema = new mongoose.Schema(
  {
    body: { type: String, required: true },
    post: { type: mongoose.Schema.Types.ObjectId, ref: "post", required: true },
  },
  {
    versionKey: false,
    timestamps: true,
  }
);

// connect comment schema to collections

const Comment = mongoose.model("comment", commentSchema);

// create schema for tag

const tagSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
  },
  {
    versionKey: false,
    timestamps: true,
  }
);

//connect tag schema to collections

const Tag = mongoose.model("tag", tagSchema);

//--------------------

const app = express();

app.use(express.json());

//--------------CRUD API --------------------------------

//post :- create a user and
app.post("/users", async (req, res) => {
  const user = await User.create(req.body);

  return res.status(201).send({ user });
});

//get :- get all users

app.get("/users", async (req, res) => {
  const user = await User.find().lean().exec();

  return res.status(200).send({ user });
});

// patch :- upadate :- update user

app.patch("/users/:id", async (req, res) => {
  const user = await User.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });

  return res.status(200).send({ user });
});

//delete :- delete user

app.delete("/users/:id", async (req, res) => {
  const user = await User.findByIdAndDelete(req.params.id).lean().exec();

  res.status(200).send({ user });
});

// get a single user

app.get("/users/:id", async (req, res) => {
  const user = await User.findById(req.params.id).lean().exec();

  return res.status(200).send({ user });
});

// -----------CRUD API for post

//post a new

app.post("/posts", async (req, res) => {
  const post = await Post.create(req.body);

  return res.status(200).send({ post });
});

//get post details

app.get("/posts", async (req, res) => {
  const post = await Post.find().lean().exec();

  return res.status(200).send({ post });
});

//single post get details

app.get("/posts", async (req, res) => {
  const post = await Post.findById(req.params.id).lean().exec();
  return res.status(200).send({ post });
});

//  update

app.patch("/posts/:id", async (req, res) => {
  const post = await Post.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });

  return res.status(200).send({ post });
});

//delete a post

app.delete("/posts/:id", async (req, res) => {
  const post = await Post.findByIdAndDelete(req.params.id).lean().exec();

  return res.status(200).send({ post });
});

//---------CRUD API for comment

//post
app.post("/comments", async (req, res) => {
  const comment = await Comment.create(req.body);
  return res.status(200).send({ comment });
});

// get comment

app.get("/comments", async (req, res) => {
  const comment = await Comment.find().lean().exec();
  return res.status(200).send({ comment });
});

//get single comment

app.get("/comments/:id", async (req, res) => {
  const comment = await Comment.findById(req.params.id).lean().exec();
  return res.status(200).send({ comment });
});

// delete comment

app.delete("/comments/:id", async (req, res) => {
  const comment = await Comment.findByIdAndDelete(req.params.id);
  return res.status(200).send({ comment });
});
// patch / update comment

app.patch("/comments/:id", async (req, res) => {
  const comment = await Comment.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  return res.status(200).send({ comment });
});

// ---------- CRUD API for tags

//post  tags

app.post("/tags", async (req, res) => {
  const tag = await Tag.create(req.body);

  return res.status(200).send({ tag });
});

//get tags

app.get("/tags", async (req, res) => {
  const tag = await Tag.find().lean().exec();

  return res.status(200).send({ tag });
});

// get single tags

app.get("/tags/:id", async (req, res) => {
  const tag = await Tag.findById(req.params.id).lean().exec();
  return res.status(200).send({ tag });
});

//patch / update tags

app.patch("/tags/:id", async (req, res) => {
  const tag = await Tag.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });

  return res.status(200).send({ tag });
});

//delete  tags

app.delete("/tags/:id", async (req, res) => {
  const tag = await Tag.findByIdAndDelete(req.params.id);
  return res.status(200).send({ tag });
});

//listening api on port
app.listen(2346, async function () {
  await connect();
  console.log("listining on 2346");
});
